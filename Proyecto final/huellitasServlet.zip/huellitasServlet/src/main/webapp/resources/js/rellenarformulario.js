 function rellenarFormulario(id, nombre, sexo, color, fechaExtravio) {
    document.getElementById("id_mascota").value = id;
    document.getElementById("nombre").value = nombre;
    document.getElementById("sexo").value = sexo;
    document.getElementById("color").value = color;
    document.getElementById("fecha_extravio").value = fechaExtravio;
    
     
  }

